# Klive IDE Extension

This preview extension integrates the Klive ZX Spectrum Emulator with Visual Studio Code, and provides a full-fledged ZX Spectrum IDE.
